import 'dart:convert';
import 'package:objectbox/objectbox.dart';
import 'package:uuid/uuid.dart';

@Entity()
class EntityTable {
  @Id()
  int tableId = 0;

  String? roomType;   // Dropdown from EntityRoomType table
  String? roomUuid;
  String? tableName;
  int? seats;

  int? billNumber; 
  bool? isActive;
  String? tableStatus; 

  @Unique()
  late String tableUid;

  String? mongoId; // ✅ MongoDB document ID
  bool isSync = false; // ✅ Whether this table is synced with MongoDB

  EntityTable({
    required this.roomType,
    required this.tableName,
    required this.seats,
    this.roomUuid,
    this.billNumber,
    this.isActive = false,
    this.tableStatus = "Available", // ✅ default status
    this.tableId = 0,
    String? tableUid, // optional UID
    this.mongoId,     // optional MongoDB ID
    this.isSync = false, // default false
  }) : tableUid = tableUid ?? const Uuid().v4(); // ✅ use passed one or generate new

  // ✅ Convert to JSON
  Map<String, dynamic> toJson() => {
        "tableId": tableId,
        "tableUid": tableUid,
        "tableName": tableName,
        "roomType": roomType,
        "roomUuid": roomUuid,
        "seats": seats,
        "billNumber": billNumber,
        "isActive": isActive ?? false,
        "tableStatus": tableStatus,
        "mongoId": mongoId,
        "isSync": isSync,
      };

  // ✅ Decode from JSON
  factory EntityTable.fromJson(Map<String, dynamic> json) {
    return EntityTable(
      tableId: 0, // always 0 for inserts
      tableName: json['tableName'],
      roomType: json['roomType'],
      roomUuid: json['roomUuid'],
      seats: json['seats'],
      billNumber: json['billNumber'],
      isActive: json['isActive'],
      tableStatus: json['tableStatus'] ?? "Available",
      tableUid: json['tableUid'],
      mongoId: json['mongoId'],
      isSync: json['isSync'] ?? false,
    );
  }
}
