import 'package:objectbox/objectbox.dart';

@Entity()
class EntityBillFood {
  @Id()
  int billFoodId = 0;

  /// 🔹 MongoDB document ID (used for sync)
  String? mongoId;

  /// 🔹 Sync status flag (false = local only, true = synced)
  bool? isSync;

  int? foodId; // FK
  String? name; // en
  String? category; // en
  int? taxPercentage; // FK from food cat
  int? quantity;
  double? price;

  EntityBillFood({
    this.mongoId, // MongoDB _id
    this.isSync = false, // default not synced
    required this.foodId,
    required this.name,
    required this.category,
    required this.taxPercentage,
    this.quantity = 1,
    this.price = 0.0,
  });

  /// ✅ Parse from JSON (preserves Mongo _id and sync status)
  factory EntityBillFood.fromJson(Map<String, dynamic> json) {
    return EntityBillFood(
      mongoId: json["_id"], // MongoDB _id
      isSync: json["isSync"] ?? false,
      foodId: json["foodId"],
      name: json["name"],
      category: json["category"],
      taxPercentage: json["taxPercentage"],
      quantity: json["quantity"] ?? 1,
      price: (json["price"] ?? 0.0).toDouble(),
    );
  }

  /// ✅ Convert to JSON for sync / broadcast
  Map<String, dynamic> toJson() {
    return {
      '_id': mongoId, // MongoDB ID
      'billFoodId': billFoodId,
      'foodId': foodId,
      'name': name,
      'category': category,
      'taxPercentage': taxPercentage,
      'quantity': quantity,
      'price': price,
      'isSync': isSync ?? false, // include sync status
    };
  }
}
