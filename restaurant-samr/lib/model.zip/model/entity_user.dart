import 'package:objectbox/objectbox.dart';
import 'package:uuid/uuid.dart';

@Entity()
class EntityUser {
  @Id()
  int? userId = 0;
  String? userName;
  String? userPassword;
  String? userType;
  String? first;
  String? last;
  String? countryCode;
  String? mobile;
  String? dob;
  String? gender;
  String? idProofKey;
    String? address;
  String? idProofValue;
  @Unique()
  late String userUuid;

  EntityUser({
    required this.userName,
    required this.userPassword,
    required this.userType,
    required this.first,
    required this.last,
    required this.countryCode,
    required this.mobile,
    required this.dob,
    required this.gender,
    this.idProofKey,
    this.idProofValue,
    this.address,
    String? userUuid,
  }) : userUuid = userUuid ?? const Uuid().v4();
}
