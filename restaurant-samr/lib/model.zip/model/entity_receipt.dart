

class Receipt {
  final int billNo;
  final String tableName;
  final String type;
   String status;
  final String customer;
  final String phone;
  final String deliveryBoy;
  final String payment;
  final double amount;
   final String billUuid;
  

  Receipt({
    required this.billNo,
    required this.tableName,
    required this.type,
    required this.status,
    required this.customer,
    required this.phone,
    required this.deliveryBoy,
    required this.payment,
    required this.amount,
        required this.billUuid,



  });
}
