import 'package:objectbox/objectbox.dart';
import 'package:splash_screen_03/model/entity_kitchen_department.dart';
import 'package:splash_screen_03/model/entity_tax.dart';
import 'package:uuid/uuid.dart';

import 'entity_name.dart';
import 'entity_price.dart';

@Entity()
class EntityFood {
  @Id()
  int foodId = 0;

  String? mongoId;

  String? shortCode;
  String? categoryName;
  String? foodDescription;
  bool? isVeg;
  String? foodType;
  bool? isActive;
  double? prepTime;
  String? hsnCode;
  int? sortIndex;
  List<String>? images;
  String? foodName;
  bool? isRecommended;
  String? kitchenDepartment;
  String? opentItem;
  String? imgPath;
  bool? isSync;
  String? menu;
  double? discountPrice;
  int qty;

  @Unique()
  late String foodUuid;

  ToOne<EntityName> name = ToOne();
  ToOne<EntityTax> tax = ToOne();
  ToMany<EntityPrice> price = ToMany();
  ToOne<EntityKitchenDepartment> kitchen = ToOne();

  EntityFood({
    this.mongoId, // ✅ MongoDB _id
    this.foodType,
    this.hsnCode,
    this.sortIndex,
    this.isRecommended = false,
    this.foodDescription,
    this.prepTime,
    this.shortCode,
    required this.foodName,
    this.isVeg = true,
    this.isActive = false,
    this.images,
    this.foodId = 0,
    this.categoryName,
    this.kitchenDepartment,
    this.opentItem,
    this.imgPath,
    this.isSync,
    this.menu,
    this.discountPrice,
    this.qty = 0,
  }) : foodUuid = const Uuid().v4();

  Map<String, dynamic> toJsonSimple() {
    return {
      "_id": mongoId, // ✅ include MongoDB _id for syncing
      "foodId": foodId,
      "foodUuid": foodUuid,
      "foodName": foodName ?? "",
      "category": categoryName ?? "",
      "isVeg": isVeg ?? true,
      "foodType": foodType ?? "",
      "kitchenDepartment": kitchenDepartment ?? "",
      "opentItem": opentItem ?? "",
      "imgPath": imgPath ?? "",
      "isSync": isSync ?? false,
      "menu": menu ?? "",
      "discountPrice": discountPrice ?? 0.0,
      "qty": qty,
      "prepTime": prepTime ?? 0.0,
      "isRecommended": isRecommended ?? false,
      "isActive": isActive ?? false,
      "hsnCode": hsnCode ?? "",
      "sortIndex": sortIndex ?? 0,
    };
  }
}
