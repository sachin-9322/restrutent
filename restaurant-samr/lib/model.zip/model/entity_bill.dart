// model/entity_bill.dart
import 'package:objectbox/objectbox.dart';
import 'package:splash_screen_03/model/entity_kot.dart';
import 'package:splash_screen_03/model/entity_payment.dart';
import 'package:uuid/uuid.dart'; 

@Entity()
class EntityBill {
  @Id()
  int billId = 0;

  String uuid = const Uuid().v4(); // unique UUID for every bill

  String? mongoId; // MongoDB document ID
  bool isSync = false; // Whether this bill is synced with MongoDB

  int? billNumber = 0; // used in table as FK
  String? status; // booked, settle
  String? startTime;
  String? endTime;
  int? printCount;
  String? tableName;
  int? tableSeat;
  String? orderType; // Dine-in, Pickup, Quick bill, Delivery
  String? userName;
  double? totalAmount;
  String? customerName;
  String? customerMobile;
  String? customerAddress;
  String? createdOn;

  String? itemsJson;       
  String? metaJson;       
  String? orderItemsJson; 
  int? totalQty;          

  // ---------- Relations ----------
  ToMany<EntityKot> listKot = ToMany();
  ToMany<Payment> payments = ToMany(); // ✅ New: multiple payments for this bill

  EntityBill({
    required this.billNumber,
    this.status,
    this.startTime,
    this.endTime,
    this.printCount,
    required this.tableName,
    required this.tableSeat,
    required this.orderType,
    required this.userName,
    required this.createdOn,
    this.totalAmount,
    this.customerAddress,
    this.customerMobile,
    this.customerName,
    this.itemsJson,
    this.metaJson,
    this.orderItemsJson,
    this.totalQty,
    String? uuid, // optional param if we ever restore from backup
    this.mongoId, // optional MongoDB ID
    this.isSync = false, // default to false
  }) : uuid = uuid ?? const Uuid().v4(); // Auto-generate if not supplied
}
