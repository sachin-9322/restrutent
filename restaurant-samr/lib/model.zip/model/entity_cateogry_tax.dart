import 'package:objectbox/objectbox.dart';

import 'entity_name.dart';

@Entity()
class EntityCategoryTax {
  @Id()
  int id = 0;
  String? categoryName;

  ToOne<EntityName> name = ToOne();

  EntityCategoryTax({required this.categoryName, this.id = 0});
}
